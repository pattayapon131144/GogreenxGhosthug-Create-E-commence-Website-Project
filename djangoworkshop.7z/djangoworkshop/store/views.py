from django.shortcuts import render,redirect,get_object_or_404
from store.models import Boxer ,Customer ,Buy ,Cart ,CartItem ,Category , Order , OrderItem
from store.forms import SignUpForm
from django.contrib.auth.models import Group,User
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.core.paginator import Paginator,EmptyPage,InvalidPage
from django.contrib.auth.decorators import login_required
from django.conf import settings
import stripe

# หน้าแรกของเว็บไซด์
def index(request,category_slug=None) :
    boxers=None
    category_page=None
    if category_slug!=None:
        category_page=get_object_or_404(Category,slug=category_slug)
        boxers=Boxer.objects.all().filter(category=category_page,Avalible=True)
    else :
        boxers=Boxer.objects.all().filter(Avalible=True)

    paginator=Paginator(boxers,9)
    try:
        page=int(request.GET.get('page','1'))
    except:
        page=1

    try:
        boxerperPage=paginator.page(page)
    except (EmptyPage,InvalidPage):
        boxerperPage=paginator.page(paginator.num_pages)

    return render(request,'index.html',{'boxers':boxerperPage,'category':category_page})

# หน้ารายละเอียดสินค้า 
def boxerDetail(request,category_slug,boxer_slug):
    try :
        boxer=Boxer.objects.get(category__slug=category_slug,slug=boxer_slug)
    except Exception as e :
        raise e
    return render(request,'boxer.html',{'boxer':boxer})

# หน้าสินค้าผู้ชาย
def menpage(request,category_slug=None) :
    #ดึงข้อมูงมาจากข้อมูลสินค้ามาแสดง
    boxers=None
    category_page=None
    if category_slug!=None:
        category_page=get_object_or_404(Category,slug=category_slug)
        boxers=Boxer.objects.all().filter(category=category_page,Avalible=True)
    else :
        boxers=Boxer.objects.all().filter(Avalible=True)

    paginator=Paginator(boxers,9) # 1 หน้าสามารขายสินค้าได้กี่ชิ้นสามารถระบุได้ในโค๊ดนี้
    #เรียงหน้า 1 2 3
    try:
        page=int(request.GET.get('page','1'))
    except:
        page=1

    try:
        boxerperPage=paginator.page(page)
    except (EmptyPage,InvalidPage):
        boxerperPage=paginator.page(paginator.num_pages)

    return render(request,'men.html',{'boxers':boxerperPage,'category':category_page})

# หน้าสินค้าหญิง
def womenpage(request):
    return render(request,'women.html')

# หน้าเมนู
def navbar(request):
    return render(request,'navbaraum.html')

# หน้าสินค้าเด็ก
def kidspage(request):
    return render(request,'kids.html')

# หน้าสินค้าใหม่
def newspage(request):
    return render(request,'news.html')


# หน้าล็อคอินสมาชิก
def signuppage(request):
    return render(request,'signup.html')

# หน้ารหัสสินค้า
def _cart_id(request):
    cart=request.session.session_key
    if not cart:
        cart=request.session.create()
    return cart

# ระบบหากจะเพิ่มสินค้าต้องทำการล็อคอิน
@login_required(login_url='signIn')
def add_Cart(request,boxer_id):
    #ดึงข้อมูงจากสินค้าเข้าตระกร้า
    boxer=Boxer.objects.get(id=boxer_id)
    try:
        cart=Cart.objects.get(cart_id=_cart_id(request))
    except Cart.DoesNotExist:
        cart=Cart.objects.create(cart_id=_cart_id(request))
        cart.save() #เซฟข้อมูลสินค้าที่กดลงตระกร้า
    try:
        cart_item=CartItem.objects.get(boxer=boxer,cart=cart)
        if cart_item.quantity<cart_item.boxer.stock :
            cart_item.quantity+=1
            cart_item.save()
    except CartItem.DoesNotExist:
        cart_item=CartItem.objects.create(
            boxer=boxer,
            cart=cart,
            quantity=1
        )
        cart_item.save()
    return redirect('/')

def cartdetail(request):
    total=0
    counter=0
    cart_items=None
    #ดึงข้อมูลจากฐานข้อมูล
    try:
        cart=Cart.objects.get(cart_id=_cart_id(request)) #ดึงตระกร้า
        cart_items=CartItem.objects.filter(cart=cart,active=True) #ดึงข้อมูลสินค้าในตระกร้า
        for item in cart_items:
            total+=(item.boxer.price*item.quantity)
            counter+=(item.quantity)
    except Exception as e :
        pass

    stripe.api_key=settings.SECRET_KEY #ระบบจ่ายเงิน
    stripe_total=int(total*100)
    description="Payment Online"
    data_key=settings.PUBLIC_KEY
#ระบบจ่ายเงิน
    if request.method=="POST":
        try :
            token=request.POST['stripeToken']
            email=request.POST['stripeEmail']
            name=request.POST['stripeBillingName']
            address=request.POST['stripeBillingAddressLine1']
            city=request.POST['stripeBillingAddressCity']
            postcode=request.POST['stripeShippingAddressZip']
            customer=stripe.Customer.create(
                email=email,
                source=token
            )
            charge=stripe.Charge.create(
                amount=stripe_total,
                currency='thb',
                description=description,
                customer=customer.id
            )
            order=Order.objects.create(
                name=name,
                address=address,
                city=city,
                postcode=postcode,
                total=total,
                email=email,
                token=token
            )
            order.save()

            for item in cart_items :
                order_item=OrderItem.objects.create(
                    boxer=item.boxer.name,
                    quantity=item.quantity,
                    price=item.boxer.price,
                    order=order
                )
                order_item.save()
                #ลดจำนวน stock
                boxer=Boxer.objects.get(id=item.boxer.id)
                boxer.stock=int(item.boxer.stock-order_item.quantity)
                boxer.save()
                item.delete()
            return redirect('thankyou')

        except stripe.error.CardError as e : #ถ้ารหัสเครดิตผิด
            return False , e

    return render(request,'cartdetail.html'
    ,dict(cart_items=cart_items,total=total,counter=counter,
    data_key=data_key,
    stripe_total=stripe_total,
    description=description,
    ))

#ลบสินค้าในตระกร้าออก
def removeCart(request,boxer_id):
    cart=Cart.objects.get(cart_id=_cart_id(request))
    boxer=get_object_or_404(Boxer,id=boxer_id)
    cartItem=CartItem.objects.get(boxer=boxer,cart=cart)
    cartItem.delete()
    return redirect('cartdetail')

#ระบบสมัครสมาชิก
def signUpView(request):
    if request.method=='POST':
        form=SignUpForm(request.POST)
        if form.is_valid():
            #บันทึกข้อมูล ๊User 
            form.save()
            #บันทึก group customer
            #ดึง username จากแบบฟอร์มมาใช้งาน
            username=form.cleaned_data.get('username')
            #ดึงข้อมูล User จากฐานข้อมูล
            signUpUser=User.objects.get(username=username)
            #จัด Group   
            customer_group=Group.objects.get(name="Customer")
            customer_group.user_set.add(signUpUser)
    else :
        form=SignUpForm()
    return render(request,"signup.html",{'form':form})

#ระบบล็อคอิน
def signInView(request):
    if request.method=='POST':
        form=AuthenticationForm(data=request.POST)
        if form.is_valid():
            username=request.POST['username']
            password=request.POST['password']
            user=authenticate(username=username,password=password)
            if user is not None :
                login(request,user)
                return redirect('index')
            else :
                return redirect('signOut')
    else:
        form=AuthenticationForm()
    return render(request,'signIn.html',{'form':form})

# ระบบล็อคเอ้าท์
def signOutView(request):
    logout(request)
    return redirect('index')

# ระบบประวัติการสั่งซื้อสินค้า
def orderHistory(request):
    if request.user.is_authenticated:
        email=str(request.user.email)
        orders=Order.objects.filter(email=email)
    else:
        return render(request,'orderHistorys.html')
    return render(request,'orders.html',{'orders':orders})

# ระบบดูรายละเอียดการสั่งซื้อสินค้า
def viewOrder(request,order_id):
    if request.user.is_authenticated:
        email=str(request.user.email)
        order=Order.objects.get(email=email,id=order_id)
        orderitem=OrderItem.objects.filter(order=order)
    return render(request,'viewOrder.html',{'order':order,'order_item':orderitem})

# หน้าขอบคุณ จบการซื้อ-ขายสินค้า
def thankyou(request):
    return render(request,'thankyou.html')

def orderHistorys(request):
    return render(request,'thankyou.html')

# ระบบการค้นหาสินค้า
def search(request):
    boxers=Boxer.objects.filter(name__contains=request.GET['title'])
    return render(request,'index.html',{'boxers':boxers})







