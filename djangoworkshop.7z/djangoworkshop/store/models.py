from django.db import models
from django.urls import reverse

#โมเดลประเภทสินค้า
class Category(models.Model):
    name =  models.CharField(max_length=30,unique=True)
    slug = models.SlugField(max_length=30,unique=True)

    def __str__(self):
        return "name:%s,"\
        %(self.name)

    def get_url(self):
        return reverse('boxer_by_category',args=[self.slug])

#โมเดลProduct
class Boxer(models.Model):
    name =  models.CharField(max_length=30)
    detail = models.CharField(max_length=1000)
    price = models.DecimalField(null=True, max_digits=12,decimal_places=2)
    image = models.ImageField(upload_to="product",blank=True,)
    stock=models.IntegerField()
    Avalible = models.BooleanField(default=True)
    slug = models.SlugField(max_length=30,null=True)
    category = models.ForeignKey(Category,on_delete=models.CASCADE,null=True)
    created = models.DateTimeField(null=True,auto_now_add=True)
    updated = models.DateTimeField(null=True,auto_now=True)


    class Meta :
        ordering=('id',)

    def __str__(self):
        return self.name
    
    def get_url(self):
        return reverse('boxerDetail',args=[self.category.slug,self.slug])

#โมเดลลูกค้า
class Customer(models.Model):
    name = models.CharField(max_length=100)
    mobile = models.CharField(max_length=20)

    def __str__ (self):
        return "customer_id:%s, name:%s"%(self.id,self.name)

#โมเดลการซื้อขาย
class Buy(models.Model):
    boxer=models.ForeignKey('Boxer',on_delete=models.CASCADE)
    customer=models.ForeignKey('Customer',on_delete=models.CASCADE)
    buy_now=models.DateTimeField(auto_now=False, auto_now_add=True)
    amount=models.DecimalField(blank=True, null=True, max_digits=3,decimal_places=2)

    def __str__(self):
        return "buy_id:%s"\
        %(self.id)

#โมเดลตระกร้าสินค้า
class Cart(models.Model):
    cart_id=models.CharField(max_length=255,blank=True)
    date_added=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.cart_id

    class Meta:
        ordering=('date_added',)

#โมเดลตระกร้าสินค้า2
class CartItem(models.Model):
    boxer=models.ForeignKey(Boxer,on_delete=models.CASCADE)
    cart=models.ForeignKey(Cart,on_delete=models.CASCADE)
    quantity=models.IntegerField()
    active=models.BooleanField(default=True)

    class Meta :
        ordering=('id',)

    def sub_total(self):
        return self.boxer.price * self.quantity

    def __str__(self):
        return self.boxer.name

#โมเดลออเดอร์รายการสินค้า
class Order(models.Model):
    name=models.CharField(max_length=225,blank=True)
    address=models.CharField(max_length=225,blank=True)
    city=models.CharField(max_length=225,blank=True)
    postcode=models.CharField(max_length=225,blank=True)
    total=models.DecimalField(max_digits=10,decimal_places=2)
    email=models.EmailField(max_length=225,blank=True)
    token=models.CharField(max_length=225,blank=True)
    created = models.DateTimeField(null=True,auto_now_add=True)

    class Meta :
        db_table='order'
        ordering=('id',)

    def __str__(self):
        return str(self.id)
        
#โมเดลออเดอร์รายการสินค้า2
class OrderItem(models.Model):
    boxer=models.CharField(max_length=250)
    quantity=models.IntegerField()
    price=models.DecimalField(max_digits=10,decimal_places=2)
    order=models.ForeignKey(Order,on_delete=models.CASCADE)
    created = models.DateTimeField(null=True,auto_now_add=True)
    updated = models.DateTimeField(null=True,auto_now=True)

    class Meta :
        db_table='OrderItem'

    def sub_total(self):
        return self.quantity*self.price

    def __str__(self):
        return self.boxer
    # Create your models here.
