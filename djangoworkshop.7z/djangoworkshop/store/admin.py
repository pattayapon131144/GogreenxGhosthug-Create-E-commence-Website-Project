from django.contrib import admin
from store.models import Boxer , Customer , Buy , Cart , CartItem , Category , Order , OrderItem

#หน้าจัดระเบียบระบบ Admin (ควบคุมเบื้องหลัง)
class BoxerAdmin(admin.ModelAdmin):
    list_display=['id','name','price','image','stock','Avalible','created','updated']
    list_per_page=10
    list_editable=['price','stock']
    list_filter=['name']

class CustomerAdmin(admin.ModelAdmin):
    list_display=['id','name', 'mobile']
    list_editable=['mobile']

class BuyAdmin(admin.ModelAdmin):
    list_display = ['id','boxer','customer','buy_now','amount']
    list_editable=['amount']
    list_filter=['boxer']

class CartAdmin(admin.ModelAdmin):
    list_display=['cart_id']


class CartItemAdmin(admin.ModelAdmin):
    list_display = ['id','boxer','cart','quantity']
    list_per_page=5

class CategoryAdmin(admin.ModelAdmin):
    list_display=['id','name']

class OrderAdmin(admin.ModelAdmin):
    list_display=['id','name','address','city','postcode','total','email','token','created']
    list_per_page=5
    list_editable=['total','email']
    list_filter=['name']

class OrderItemAdmin(admin.ModelAdmin):
    list_display=['boxer','quantity','price','order','created','updated']
    list_per_page=5
    list_filter=['boxer']


admin.site.register(Boxer,BoxerAdmin)
admin.site.register(Customer,CustomerAdmin)  
admin.site.register(Buy,BuyAdmin)
admin.site.register(CartItem,CartItemAdmin)
admin.site.register(Cart,CartAdmin)
admin.site.register(Category,CategoryAdmin)
admin.site.register(Order,OrderAdmin)
admin.site.register(OrderItem,OrderItemAdmin)



# Register your models here.
